## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "",
  root.dir=normalizePath('../'),
  cache = TRUE,
  echo = FALSE,
  message = FALSE,
  warning=FALSE,
  fig.width=7.5,
  fig.height=5
)

library(ggplot2)
library(jsonlite)
library(sp)

## ----incidencQuery-------------------------------------------------------
toJSON(fromJSON('{
  "output": ["incidence"],
  "attributes": ["Census_Tract", "vax_status"],
  "basis": ["year"],
  "values": ["incidence_median", "incidence_sd"]
}'),pretty=TRUE) 

## ----rawDataQuery--------------------------------------------------------
toJSON(fromJSON('{
  "output": ["observed"],
  "attributes": ["Census_Tract", "vax_status"],
  "basis": ["year"],
  "values": ["flu_count", "nsamples"]
}'),pretty=TRUE)

## ----output--------------------------------------------------------------
toJSON(fromJSON('{
  "output": ["incidence"],
  "attributes": ["Census_Tract", "vax_status"],
  "basis": ["year"],
  "values": ["incidence_median", "incidence_sd"],
  "data" : [
    { "Census_Tract": 53003960100, 
      "vax_status": 0,
      "data": [
        {"year": 2018.8462, "incidence_median": 0.0031, "incidence_sd": 0.211},
        {"year": 2018.8654, "incidence_median": 0.0055, "incidence_sd": 0.1815}, 
        {"year": 2018.8846, "incidence_median": 0.012, "incidence_sd": 0.164},
        {"...": "..."}
      ]
    },
    { "Census_Tract": 53005010400, 
      "vax_status": 0, 
      "data": [
        {"year": 2018.8462, "incidence_median": 0.0212, "incidence_sd": 0.2186},
        {"...": "..."}
      ]
    }
  ]                                                     
}'),pretty=TRUE)

## ----map, results='hide'-------------------------------------------------
kcShapes <- sf::st_read(paste(knitr::opts_chunk$get('root.dir'),"inst/extdata/censusData","cb_2017_53_tract_500k.shp",sep="/"))
kcShapes <- kcShapes[kcShapes$COUNTYFP=='033',]
kcShapes$rowID<-1:nrow(kcShapes)
kcShapes$Census_Tract <- as.numeric(levels(kcShapes$GEOID))[kcShapes$GEOID]

kcNeighborGraph <- INLA::inla.read.graph(filename = paste(knitr::opts_chunk$get('root.dir'),"inst/extdata/censusData","kc.adj",sep="/"))

# plot(sf::st_geometry(kcShapes), border="grey", lwd=0.1)
# plot(kcNeighborGraph, sp::coordinates(as(kcShapes,"Spatial")), points=FALSE, add=TRUE, lwd=0.5)

## ----mapshow, out.width = '100%'-----------------------------------------
knitr::include_graphics("kcmap.png")

## ----data----------------------------------------------------------------
linelist <- read.csv(paste(knitr::opts_chunk$get('root.dir'),"inst/extdata","infection_individuals_0.01nonflu.csv",sep="/"))
# linelist <- read.csv(paste("inst/extdata","infection_individuals_0.01nonflu.csv",sep="/"))

simulatedData <- read.csv(paste(knitr::opts_chunk$get('root.dir'),"inst/extdata","simulatedInfluenzaByTract.csv",sep="/"))
simulatedData<-simulatedData[!is.na(simulatedData$year),]
# simulatedData <- read.csv(system.file("extdata","simulatedInfluenzaByTract.csv",package = "predictModelTestPkg"))

## ----truthTimeseries, fig.show='hold'------------------------------------
ggplot(linelist, aes(x=year)) + geom_histogram(breaks = unique(simulatedData$year)) + facet_wrap(.~Diagnosis)

## ----truthCount, fig.show='hold', fig.height=18--------------------------
t<-dplyr::right_join(simulatedData,kcShapes)
  
ggplot()  + geom_sf(data=t[ t$vax_status==0,],aes(fill = flu_count), size=0, inherit.aes = FALSE)  + 
    facet_wrap(.~year, ncol = 3) +
    theme_bw() + theme(axis.text=element_blank(),axis.ticks=element_blank()) +
    viridis::scale_fill_viridis(trans='log', breaks=c(1,5,10,20,50,100), name="flu cases", na.value="transparent") +
    xlab('')+ylab('') +
    xlim(c(-122.5, -121.7)) + ylim(c(47.15,47.77))

## ----truthPrevalence, fig.show='hold', fig.height=18---------------------
ggplot()  + geom_sf(data=t[ t$vax_status==0,],aes(fill = flu_count/nsamples), size=0, inherit.aes = FALSE)  + 
    facet_wrap(.~year, ncol = 3) +
    theme_bw() + theme(axis.text=element_blank(),axis.ticks=element_blank()) +
    viridis::scale_fill_viridis(breaks=seq(0.1,0.9, by=0.4), name="flu in ILI", na.value="transparent") +
    xlab('')+ylab('') +
    xlim(c(-122.5, -121.7)) + ylim(c(47.15,47.77))

## ----observedPrevalence, fig.show='hold', fig.height=18------------------
observedData <- read.csv(paste(knitr::opts_chunk$get('root.dir'),"inst/extdata","observedInfluenzaByTract.csv",sep="/"))
observedData<-observedData[!is.na(observedData$year),]
# observedData <- read.csv(system.file("extdata","observedInfluenzaByTract.csv",package = "predictModelTestPkg"))

t<-dplyr::right_join(observedData,kcShapes)
  
ggplot()  + geom_sf(data=t[ t$vax_status==0,],aes(fill = flu_count/nsamples), size=0, inherit.aes = FALSE)  + 
    facet_wrap(.~year, ncol = 3) +
    theme_bw() + theme(axis.text=element_blank(),axis.ticks=element_blank()) +
    viridis::scale_fill_viridis(breaks=seq(0.1,0.9, by=0.4), name="flu in ILI", na.value="transparent") +
    xlab('')+ylab('') +
    xlim(c(-122.5, -121.7)) + ylim(c(47.15,47.77))

## ----predictedPrevalence, fig.show='hold', fig.height=18-----------------
predictedData <- read.csv(paste(knitr::opts_chunk$get('root.dir'),"inst/extdata","predictedInfluenzaByTract.csv",sep="/"))
# predictedData <- read.csv(system.file("extdata","predictedInfluenzaByTract.csv",package = "predictModelTestPkg"))

t<-dplyr::right_join(predictedData,kcShapes)
t<-t[!is.na(t$year),]

ggplot()  + geom_sf(data=t[ t$vax_status==0,],aes(fill = incidence_median), size=0, inherit.aes = FALSE)  + 
    facet_wrap(.~year, ncol = 3) +
    theme_bw() + theme(axis.text=element_blank(),axis.ticks=element_blank()) +
    viridis::scale_fill_viridis(breaks=seq(0.1,0.9, by=0.4), name="flu in ILI", na.value="transparent") +
    xlab('')+ylab('') +
    xlim(c(-122.5, -121.7)) + ylim(c(47.15,47.77))

## ----predictedTimeseries, fig.show='hold'--------------------------------
t<-dplyr::left_join(t,observedData,by=c('Census_Tract','vax_status','year'))

t<-t[!is.na(t$year),]

tmp<-dplyr::filter(t,Census_Tract %in% unique(t$Census_Tract)[c(2,20,100,240)])
  
ggplot(tmp,aes(x=year,y=flu_count/nsamples,group=vax_status, color=as.factor(vax_status))) +
    geom_point() + facet_wrap(.~Census_Tract) +
    geom_line(aes(year,incidence_median)) +
    geom_ribbon(aes(x=year,ymin=incidence_lower95,ymax=incidence_upper95,fill=as.factor(vax_status)),alpha=0.3,color=NA) +
    guides(color = guide_legend(title = "vax status"),fill=FALSE)


